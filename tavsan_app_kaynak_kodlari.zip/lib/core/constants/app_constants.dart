
// ============================================================
// lib/core/constants/app_constants.dart
// ============================================================
class AppConstants {
  static const String appName = 'Tavşan';
  static const int GIFT_EFFECT_THRESHOLD = 80;
  static const int GIFT_COIN_EXPLOSION_THRESHOLD = 100;
  static const int FAMILY_CREATE_COST = 20000;
  static const int FAMILY_RENAME_COST = 10000;
  static const int FAMILY_EMBLEM_COST = 5000;
  static const int FAMILY_SHIELD_COST = 300000;
  static const int FAMILY_SHIELD_DAYS = 7;
  static const int DAILY_CAPSULE_FREE = 1;
  static const double THEFT_SUCCESS_RATE = 0.30;
  static const int OTP_EXPIRY_MINUTES = 5;
}

// ============================================================
// lib/core/models/gift_model.dart
// ============================================================
class GiftModel {
  final String id;
  final String name;
  final String emoji;
  final int price;
  final int charmPoints;
  final GiftCategory category;
  final GiftEffect effect;
  final String? animationPath;
  final String? soundPath;

  GiftModel({
    required this.id,
    required this.name,
    required this.emoji,
    required this.price,
    required this.charmPoints,
    required this.category,
    this.effect = GiftEffect.none,
    this.animationPath,
    this.soundPath,
  });

  bool get hasEffect => price > AppConstants.GIFT_EFFECT_THRESHOLD;
  bool get canExplodeCoins => price >= AppConstants.GIFT_COIN_EXPLOSION_THRESHOLD;
}

enum GiftCategory { basic, medium, big, mega }
enum GiftEffect { none, small, medium, big, mega }

class GiftDatabase {
  static final List<GiftModel> allGifts = [
    // BASİT (1-50) - 12 hediye
    GiftModel(id: 'g1', name: 'Havuç', emoji: '🥕', price: 1, charmPoints: 1, category: GiftCategory.basic),
    GiftModel(id: 'g2', name: 'Gül', emoji: '🌹', price: 2, charmPoints: 1, category: GiftCategory.basic),
    GiftModel(id: 'g3', name: 'Balon', emoji: '🎈', price: 3, charmPoints: 1, category: GiftCategory.basic),
    GiftModel(id: 'g4', name: 'Öpücük', emoji: '💋', price: 5, charmPoints: 2, category: GiftCategory.basic),
    GiftModel(id: 'g5', name: 'Çikolata', emoji: '🍫', price: 8, charmPoints: 2, category: GiftCategory.basic),
    GiftModel(id: 'g6', name: 'Ayıcık', emoji: '🧸', price: 10, charmPoints: 3, category: GiftCategory.basic),
    GiftModel(id: 'g7', name: 'Lolipop', emoji: '🍭', price: 12, charmPoints: 3, category: GiftCategory.basic),
    GiftModel(id: 'g8', name: 'Fiyonk', emoji: '🎀', price: 15, charmPoints: 4, category: GiftCategory.basic),
    GiftModel(id: 'g9', name: 'Yıldız', emoji: '🌟', price: 20, charmPoints: 5, category: GiftCategory.basic),
    GiftModel(id: 'g10', name: 'Şarap', emoji: '🍷', price: 25, charmPoints: 6, category: GiftCategory.basic),
    GiftModel(id: 'g11', name: 'Gitar', emoji: '🎸', price: 30, charmPoints: 7, category: GiftCategory.basic),
    GiftModel(id: 'g12', name: 'Scooter', emoji: '🏍️', price: 50, charmPoints: 10, category: GiftCategory.basic),

    // ORTA (80-800) - 12 hediye
    GiftModel(id: 'g13', name: 'Dünya Bayrağı', emoji: '🌍', price: 80, charmPoints: 16, category: GiftCategory.medium, effect: GiftEffect.small),
    GiftModel(id: 'g14', name: 'Havai Fişek', emoji: '🎆', price: 120, charmPoints: 24, category: GiftCategory.medium, effect: GiftEffect.small),
    GiftModel(id: 'g15', name: 'Sürpriz Kutu', emoji: '🎁', price: 160, charmPoints: 32, category: GiftCategory.medium, effect: GiftEffect.small),
    GiftModel(id: 'g16', name: 'Dönme Dolap', emoji: '🎡', price: 200, charmPoints: 40, category: GiftCategory.medium, effect: GiftEffect.small),
    GiftModel(id: 'g17', name: 'Atlıkarınca', emoji: '🎠', price: 250, charmPoints: 50, category: GiftCategory.medium, effect: GiftEffect.small),
    GiftModel(id: 'g18', name: 'Minik Kale', emoji: '🏰', price: 300, charmPoints: 60, category: GiftCategory.medium, effect: GiftEffect.small),
    GiftModel(id: 'g19', name: 'Eski Araba', emoji: '🚗', price: 350, charmPoints: 70, category: GiftCategory.medium, effect: GiftEffect.small),
    GiftModel(id: 'g20', name: 'Drone', emoji: '🚁', price: 400, charmPoints: 80, category: GiftCategory.medium, effect: GiftEffect.small),
    GiftModel(id: 'g21', name: 'Tekne', emoji: '🚤', price: 500, charmPoints: 100, category: GiftCategory.medium, effect: GiftEffect.small),
    GiftModel(id: 'g22', name: 'Sirk Çadırı', emoji: '🎪', price: 600, charmPoints: 120, category: GiftCategory.medium, effect: GiftEffect.small),
    GiftModel(id: 'g23', name: 'Chopper', emoji: '🏍️', price: 700, charmPoints: 140, category: GiftCategory.medium, effect: GiftEffect.small),
    GiftModel(id: 'g24', name: 'Sahne', emoji: '🎤', price: 800, charmPoints: 160, category: GiftCategory.medium, effect: GiftEffect.small),

    // BÜYÜK (1.000-10.000) - 9 hediye
    GiftModel(id: 'g25', name: 'Spor Araba', emoji: '🏎️', price: 1000, charmPoints: 200, category: GiftCategory.big, effect: GiftEffect.medium),
    GiftModel(id: 'g26', name: 'Helikopter', emoji: '🚁', price: 1500, charmPoints: 300, category: GiftCategory.big, effect: GiftEffect.medium),
    GiftModel(id: 'g27', name: 'Orta Kale', emoji: '🏰', price: 2000, charmPoints: 400, category: GiftCategory.big, effect: GiftEffect.medium),
    GiftModel(id: 'g28', name: 'Yat', emoji: '🚢', price: 3000, charmPoints: 600, category: GiftCategory.big, effect: GiftEffect.medium),
    GiftModel(id: 'g29', name: 'Dev Sirk', emoji: '🎪', price: 4000, charmPoints: 800, category: GiftCategory.big, effect: GiftEffect.medium),
    GiftModel(id: 'g30', name: 'Eşref Tekin Araba', emoji: '🏎️', price: 5000, charmPoints: 1000, category: GiftCategory.big, effect: GiftEffect.medium),
    GiftModel(id: 'g31', name: 'Özel Jet', emoji: '✈️', price: 6000, charmPoints: 1200, category: GiftCategory.big, effect: GiftEffect.medium),
    GiftModel(id: 'g32', name: 'Büyük Kale', emoji: '🏰', price: 8000, charmPoints: 1600, category: GiftCategory.big, effect: GiftEffect.medium),
    GiftModel(id: 'g33', name: 'Lamborghini', emoji: '🏎️', price: 10000, charmPoints: 2000, category: GiftCategory.big, effect: GiftEffect.medium),

    // MEGA (15.000-50.000) - 7 hediye
    GiftModel(id: 'g34', name: 'Futbol Sahası', emoji: '⚽', price: 15000, charmPoints: 3000, category: GiftCategory.mega, effect: GiftEffect.big),
    GiftModel(id: 'g35', name: 'Altın Helikopter', emoji: '🚁', price: 20000, charmPoints: 4000, category: GiftCategory.mega, effect: GiftEffect.big),
    GiftModel(id: 'g36', name: 'Altın Araba', emoji: '🏎️', price: 25000, charmPoints: 5000, category: GiftCategory.mega, effect: GiftEffect.big),
    GiftModel(id: 'g37', name: 'Şato', emoji: '🏰', price: 30000, charmPoints: 6000, category: GiftCategory.mega, effect: GiftEffect.big),
    GiftModel(id: 'g38', name: 'Kruvazör', emoji: '🚢', price: 35000, charmPoints: 7000, category: GiftCategory.mega, effect: GiftEffect.big),
    GiftModel(id: 'g39', name: 'Mafi Arabası', emoji: '🚗', price: 40000, charmPoints: 8000, category: GiftCategory.mega, effect: GiftEffect.big),
    GiftModel(id: 'g40', name: 'TAVŞAN', emoji: '🐰', price: 50000, charmPoints: 10000, category: GiftCategory.mega, effect: GiftEffect.mega),
  ];

  static List<GiftModel> getGiftsByCategory(GiftCategory category) {
    return allGifts.where((g) => g.category == category).toList();
  }
}
