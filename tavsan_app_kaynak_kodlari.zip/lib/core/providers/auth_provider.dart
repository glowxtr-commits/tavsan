
// ============================================================
// lib/core/services/theft_service.dart
// ============================================================
import 'dart:math';

class CapsuleResult {
  final CapsuleItemType type;
  final int? amount;
  final String? itemId;
  final String description;

  CapsuleResult({
    required this.type,
    this.amount,
    this.itemId,
    required this.description,
  });
}

enum CapsuleItemType { coins, shield, theftChance, nothing, familyFund }

class TheftService {
  static final Random _random = Random();

  static CapsuleResult openDailyCapsule() {
    final roll = _random.nextDouble();

    // %25 - Boş
    if (roll < 0.25) {
      return CapsuleResult(
        type: CapsuleItemType.nothing,
        description: 'Bugün şansın yok, yarın tekrar dene!',
      );
    }
    // %35 - Jeton (100-1000)
    else if (roll < 0.60) {
      final coins = 100 + _random.nextInt(901);
      return CapsuleResult(
        type: CapsuleItemType.coins,
        amount: coins,
        description: '$coins jeton kazandın!',
      );
    }
    // %20 - Koruma Kalkanı (1 günlük)
    else if (roll < 0.80) {
      return CapsuleResult(
        type: CapsuleItemType.shield,
        description: '1 günlük koruma kalkanı kazandın!',
      );
    }
    // %15 - Hırsızlık Şansı
    else if (roll < 0.95) {
      return CapsuleResult(
        type: CapsuleItemType.theftChance,
        description: 'Hırsızlık şansı kazandın! Bir aileden çalabilirsin.',
      );
    }
    // %5 - Aile Fonu (1000-5000)
    else {
      final fund = 1000 + _random.nextInt(4001);
      return CapsuleResult(
        type: CapsuleItemType.familyFund,
        amount: fund,
        description: 'Ailene $fund fon kazandın!',
      );
    }
  }

  static bool attemptTheft() {
    return _random.nextDouble() < 0.30; // %30 başarı şansı
  }
}

// ============================================================
// lib/core/providers/auth_provider.dart
// ============================================================
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

enum AuthMethod { phone, email, apple, twitter, facebook }

class AuthProvider extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  User? _user;
  bool _isLoading = false;
  String? _verificationId;

  User? get user => _user;
  bool get isLoading => _isLoading;
  bool get isAuthenticated => _user != null;

  AuthProvider() {
    _auth.authStateChanges().listen((User? user) {
      _user = user;
      notifyListeners();
    });
  }

  Future<void> sendPhoneOTP(String phoneNumber) async {
    _isLoading = true;
    notifyListeners();
    try {
      await _auth.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        verificationCompleted: (PhoneAuthCredential credential) async {
          await _auth.signInWithCredential(credential);
        },
        verificationFailed: (FirebaseAuthException e) { throw e; },
        codeSent: (String verificationId, int? resendToken) {
          _verificationId = verificationId;
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          _verificationId = verificationId;
        },
        timeout: const Duration(minutes: 2),
      );
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> verifyPhoneOTP(String smsCode) async {
    if (_verificationId == null) return false;
    _isLoading = true;
    notifyListeners();
    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: _verificationId!, smsCode: smsCode,
      );
      await _auth.signInWithCredential(credential);
      return true;
    } catch (e) {
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> sendEmailLink(String email) async {
    _isLoading = true;
    notifyListeners();
    try {
      final actionCodeSettings = ActionCodeSettings(
        url: 'https://tavsan.app/email-signin',
        handleCodeInApp: true,
        androidPackageName: 'com.tavsan.app',
        androidInstallApp: true,
        iOSBundleId: 'com.tavsan.app',
      );
      await _auth.sendSignInLinkToEmail(
        email: email, actionCodeSettings: actionCodeSettings,
      );
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> signInWithGoogle() async {
    _isLoading = true;
    notifyListeners();
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser == null) return;
      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken, idToken: googleAuth.idToken,
      );
      await _auth.signInWithCredential(credential);
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> signOut() async {
    await _auth.signOut();
    await _googleSignIn.signOut();
    _user = null;
    _verificationId = null;
    notifyListeners();
  }
}

// ============================================================
// lib/core/providers/gift_provider.dart
// ============================================================
import 'package:flutter/material.dart';
import '../models/gift_model.dart';
import '../services/coin_explosion_service.dart';

class GiftProvider extends ChangeNotifier {
  List<GiftModel> get basicGifts => GiftDatabase.getGiftsByCategory(GiftCategory.basic);
  List<GiftModel> get mediumGifts => GiftDatabase.getGiftsByCategory(GiftCategory.medium);
  List<GiftModel> get bigGifts => GiftDatabase.getGiftsByCategory(GiftCategory.big);
  List<GiftModel> get megaGifts => GiftDatabase.getGiftsByCategory(GiftCategory.mega);

  CoinExplosionResult? _lastExplosion;
  CoinExplosionResult? get lastExplosion => _lastExplosion;

  CoinExplosionResult sendGift(GiftModel gift) {
    _lastExplosion = CoinExplosionService.calculateExplosion(gift.price);
    notifyListeners();
    return _lastExplosion!;
  }
}

// ============================================================
// lib/core/providers/family_provider.dart
// ============================================================
import 'package:flutter/material.dart';
import '../models/family_model.dart';

class FamilyProvider extends ChangeNotifier {
  FamilyModel? _currentFamily;
  FamilyModel? get currentFamily => _currentFamily;

  void createFamily(String name, String emblem) {
    _currentFamily = FamilyModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: name,
      emblem: emblem,
      level: 1,
      memberCount: 1,
      maxMembers: 20,
      fund: 0,
      dailyFundCost: 0,
      leaderCount: 1,
      adminCount: 2,
      managerCount: 0,
      createdAt: DateTime.now(),
      leaderId: 'current_user',
      members: ['current_user'],
      totalActivity: 0,
    );
    notifyListeners();
  }

  bool canUpgradeLevel() {
    if (_currentFamily == null) return false;
    if (_currentFamily!.level >= 12) return false;
    final nextConfig = FamilyModel.getLevelConfig(_currentFamily!.level + 1);
    return _currentFamily!.fund >= (nextConfig['fundReq'] as int);
  }

  void upgradeLevel() {
    if (!canUpgradeLevel()) return;
    final nextConfig = FamilyModel.getLevelConfig(_currentFamily!.level + 1);
    _currentFamily = FamilyModel(
      id: _currentFamily!.id,
      name: _currentFamily!.name,
      emblem: _currentFamily!.emblem,
      level: _currentFamily!.level + 1,
      memberCount: _currentFamily!.memberCount,
      maxMembers: nextConfig['maxMembers'] as int,
      fund: _currentFamily!.fund - (nextConfig['fundReq'] as int),
      dailyFundCost: nextConfig['dailyCost'] as int,
      leaderCount: nextConfig['leaderAsst'] as int,
      adminCount: nextConfig['admin'] as int,
      managerCount: nextConfig['manager'] as int,
      hasShield: _currentFamily!.hasShield,
      shieldExpiry: _currentFamily!.shieldExpiry,
      createdAt: _currentFamily!.createdAt,
      leaderId: _currentFamily!.leaderId,
      members: _currentFamily!.members,
      totalActivity: _currentFamily!.totalActivity,
    );
    notifyListeners();
  }
}

// ============================================================
// lib/core/providers/chat_provider.dart
// ============================================================
import 'package:flutter/material.dart';
import '../models/chat_room_model.dart';

class ChatProvider extends ChangeNotifier {
  final List<ChatRoomModel> _rooms = [];
  List<ChatRoomModel> get rooms => _rooms;

  ChatRoomModel? _currentRoom;
  ChatRoomModel? get currentRoom => _currentRoom;

  void createRoom(String name, String theme) {
    final room = ChatRoomModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: name,
      theme: theme,
      seats: ChatRoomModel.createDefaultSeats(),
      messages: [],
      createdAt: DateTime.now(),
      ownerId: 'current_user',
    );
    _rooms.add(room);
    notifyListeners();
  }

  void joinRoom(String roomId) {
    _currentRoom = _rooms.firstWhere((r) => r.id == roomId);
    notifyListeners();
  }

  void sendMessage(String content) {
    if (_currentRoom == null) return;
    final message = ChatMessageModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      userId: 'current_user',
      userName: 'Kullanıcı',
      content: content,
      timestamp: DateTime.now(),
    );
    _currentRoom!.messages.add(message);
    notifyListeners();
  }

  void sendGift(String giftId, int count) {
    if (_currentRoom == null) return;
    final message = ChatMessageModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      userId: 'current_user',
      userName: 'Kullanıcı',
      content: 'Hediye gönderdi',
      timestamp: DateTime.now(),
      type: MessageType.gift,
      giftId: giftId,
      giftCount: count,
    );
    _currentRoom!.messages.add(message);
    notifyListeners();
  }
}

// ============================================================
// lib/core/providers/user_provider.dart
// ============================================================
import 'package:flutter/material.dart';
import '../models/user_model.dart';

class UserProvider extends ChangeNotifier {
  UserModel? _user;
  UserModel? get user => _user;

  void createUser(String nickname, Gender gender) {
    _user = UserModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      nickname: nickname,
      gender: gender,
      createdAt: DateTime.now(),
      lastActive: DateTime.now(),
    );
    notifyListeners();
  }

  void addCoins(int amount) {
    if (_user == null) return;
    _user = UserModel(
      id: _user!.id,
      nickname: _user!.nickname,
      phone: _user!.phone,
      email: _user!.email,
      avatarUrl: _user!.avatarUrl,
      gender: _user!.gender,
      charmPoints: _user!.charmPoints,
      totalCoins: _user!.totalCoins + amount,
      level: _user!.level,
      experience: _user!.experience,
      familyId: _user!.familyId,
      familyRole: _user!.familyRole,
      ownedFrames: _user!.ownedFrames,
      ownedRings: _user!.ownedRings,
      currentFrame: _user!.currentFrame,
      currentRing: _user!.currentRing,
      createdAt: _user!.createdAt,
      lastActive: _user!.lastActive,
      dailyActivityMinutes: _user!.dailyActivityMinutes,
      isOnline: _user!.isOnline,
    );
    notifyListeners();
  }

  void addCharmPoints(int points) {
    if (_user == null) return;
    _user = UserModel(
      id: _user!.id,
      nickname: _user!.nickname,
      phone: _user!.phone,
      email: _user!.email,
      avatarUrl: _user!.avatarUrl,
      gender: _user!.gender,
      charmPoints: _user!.charmPoints + points,
      totalCoins: _user!.totalCoins,
      level: _user!.level,
      experience: _user!.experience,
      familyId: _user!.familyId,
      familyRole: _user!.familyRole,
      ownedFrames: _user!.ownedFrames,
      ownedRings: _user!.ownedRings,
      currentFrame: _user!.currentFrame,
      currentRing: _user!.currentRing,
      createdAt: _user!.createdAt,
      lastActive: _user!.lastActive,
      dailyActivityMinutes: _user!.dailyActivityMinutes,
      isOnline: _user!.isOnline,
    );
    notifyListeners();
  }
}
