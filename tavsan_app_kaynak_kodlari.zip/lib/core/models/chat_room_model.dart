
// ============================================================
// lib/core/services/coin_explosion_service.dart
// ============================================================
import 'dart:math';
import 'package:flutter/material.dart';

class CoinExplosionResult {
  final int coinAmount;
  final ExplosionType type;
  final double chance;

  CoinExplosionResult({
    required this.coinAmount,
    required this.type,
    required this.chance,
  });
}

enum ExplosionType { low, medium, high, jackpot }

class CoinExplosionService {
  static final Random _random = Random();

  static CoinExplosionResult calculateExplosion(int giftPrice) {
    if (giftPrice < 100) {
      return CoinExplosionResult(coinAmount: 0, type: ExplosionType.low, chance: 0);
    }

    final roll = _random.nextDouble();

    // %70 Düşük Patlama (%5-15)
    if (roll < 0.70) {
      final percent = 5 + _random.nextDouble() * 10;
      return CoinExplosionResult(
        coinAmount: (giftPrice * percent / 100).round(),
        type: ExplosionType.low,
        chance: 0.70,
      );
    }
    // %20 Orta Patlama (%20-40)
    else if (roll < 0.90) {
      final percent = 20 + _random.nextDouble() * 20;
      return CoinExplosionResult(
        coinAmount: (giftPrice * percent / 100).round(),
        type: ExplosionType.medium,
        chance: 0.20,
      );
    }
    // %8 Yüksek Patlama (%50-80)
    else if (roll < 0.98) {
      final percent = 50 + _random.nextDouble() * 30;
      return CoinExplosionResult(
        coinAmount: (giftPrice * percent / 100).round(),
        type: ExplosionType.high,
        chance: 0.08,
      );
    }
    // %2 Jackpot (%100-200)
    else {
      final percent = 100 + _random.nextDouble() * 100;
      return CoinExplosionResult(
        coinAmount: (giftPrice * percent / 100).round(),
        type: ExplosionType.jackpot,
        chance: 0.02,
      );
    }
  }

  static String getExplosionText(ExplosionType type) {
    switch (type) {
      case ExplosionType.low: return 'Düşük Patlama!';
      case ExplosionType.medium: return 'Orta Patlama!';
      case ExplosionType.high: return 'Yüksek Patlama!';
      case ExplosionType.jackpot: return '🎰 JACKPOT!!!';
    }
  }

  static Color getExplosionColor(ExplosionType type) {
    switch (type) {
      case ExplosionType.low: return const Color(0xFF4CAF50);
      case ExplosionType.medium: return const Color(0xFFFF9800);
      case ExplosionType.high: return const Color(0xFFF44336);
      case ExplosionType.jackpot: return const Color(0xFFFFD700);
    }
  }
}

// ============================================================
// lib/core/models/family_model.dart
// ============================================================
class FamilyModel {
  final String id;
  final String name;
  final String emblem;
  final int level;
  final int memberCount;
  final int maxMembers;
  final int fund;
  final int dailyFundCost;
  final int leaderCount;
  final int adminCount;
  final int managerCount;
  final bool hasShield;
  final DateTime? shieldExpiry;
  final DateTime createdAt;
  final String leaderId;
  final List<String> members;
  final int totalActivity;

  FamilyModel({
    required this.id,
    required this.name,
    required this.emblem,
    required this.level,
    required this.memberCount,
    required this.maxMembers,
    required this.fund,
    required this.dailyFundCost,
    required this.leaderCount,
    required this.adminCount,
    required this.managerCount,
    this.hasShield = false,
    this.shieldExpiry,
    required this.createdAt,
    required this.leaderId,
    required this.members,
    required this.totalActivity,
  });

  static final List<Map<String, dynamic>> levelConfig = [
    {'level': 1, 'maxMembers': 20, 'fundReq': 0, 'dailyCost': 0, 'leaderAsst': 1, 'admin': 2, 'manager': 0},
    {'level': 2, 'maxMembers': 40, 'fundReq': 30000, 'dailyCost': 100, 'leaderAsst': 1, 'admin': 2, 'manager': 0},
    {'level': 3, 'maxMembers': 60, 'fundReq': 80000, 'dailyCost': 300, 'leaderAsst': 1, 'admin': 3, 'manager': 0},
    {'level': 4, 'maxMembers': 80, 'fundReq': 150000, 'dailyCost': 600, 'leaderAsst': 1, 'admin': 3, 'manager': 0},
    {'level': 5, 'maxMembers': 120, 'fundReq': 300000, 'dailyCost': 1200, 'leaderAsst': 2, 'admin': 4, 'manager': 0},
    {'level': 6, 'maxMembers': 180, 'fundReq': 600000, 'dailyCost': 2500, 'leaderAsst': 2, 'admin': 5, 'manager': 0},
    {'level': 7, 'maxMembers': 250, 'fundReq': 1200000, 'dailyCost': 5000, 'leaderAsst': 3, 'admin': 5, 'manager': 1},
    {'level': 8, 'maxMembers': 320, 'fundReq': 2500000, 'dailyCost': 10000, 'leaderAsst': 3, 'admin': 6, 'manager': 1},
    {'level': 9, 'maxMembers': 400, 'fundReq': 5000000, 'dailyCost': 20000, 'leaderAsst': 3, 'admin': 6, 'manager': 2},
    {'level': 10, 'maxMembers': 480, 'fundReq': 10000000, 'dailyCost': 40000, 'leaderAsst': 4, 'admin': 8, 'manager': 2},
    {'level': 11, 'maxMembers': 540, 'fundReq': 20000000, 'dailyCost': 80000, 'leaderAsst': 4, 'admin': 8, 'manager': 3},
    {'level': 12, 'maxMembers': 600, 'fundReq': 40000000, 'dailyCost': 150000, 'leaderAsst': 5, 'admin': 10, 'manager': 3},
  ];

  static Map<String, dynamic> getLevelConfig(int level) {
    if (level < 1 || level > 12) return levelConfig[0];
    return levelConfig[level - 1];
  }
}

// ============================================================
// lib/core/models/coin_package.dart
// ============================================================
class CoinPackage {
  final String id;
  final String name;
  final String emoji;
  final int coinAmount;
  final double priceTL;
  final int bonusCoins;

  CoinPackage({
    required this.id,
    required this.name,
    required this.emoji,
    required this.coinAmount,
    required this.priceTL,
    required this.bonusCoins,
  });

  int get totalCoins => coinAmount + bonusCoins;
}

class CoinPackageDatabase {
  static final List<CoinPackage> packages = [
    CoinPackage(id: 'p1', name: 'Mini Havuç', emoji: '🥕', coinAmount: 100, priceTL: 5, bonusCoins: 0),
    CoinPackage(id: 'p2', name: 'Havuç', emoji: '🥕', coinAmount: 250, priceTL: 12, bonusCoins: 10),
    CoinPackage(id: 'p3', name: 'Büyük Havuç', emoji: '🥕', coinAmount: 500, priceTL: 22, bonusCoins: 25),
    CoinPackage(id: 'p4', name: 'Yıldız', emoji: '🌟', coinAmount: 1000, priceTL: 40, bonusCoins: 60),
    CoinPackage(id: 'p5', name: 'Parlak Yıldız', emoji: '🌟', coinAmount: 2000, priceTL: 75, bonusCoins: 150),
    CoinPackage(id: 'p6', name: 'Elmas', emoji: '💎', coinAmount: 5000, priceTL: 170, bonusCoins: 400),
    CoinPackage(id: 'p7', name: 'Parlak Elmas', emoji: '💎', coinAmount: 10000, priceTL: 320, bonusCoins: 900),
    CoinPackage(id: 'p8', name: 'Taç', emoji: '👑', coinAmount: 20000, priceTL: 600, bonusCoins: 2000),
    CoinPackage(id: 'p9', name: 'Altın Taç', emoji: '👑', coinAmount: 35000, priceTL: 1000, bonusCoins: 4000),
    CoinPackage(id: 'p10', name: 'TAVŞAN', emoji: '🐰', coinAmount: 50000, priceTL: 1400, bonusCoins: 6000),
  ];
}

// ============================================================
// lib/core/models/chat_room_model.dart
// ============================================================
class ChatRoomModel {
  final String id;
  final String name;
  final String theme;
  final bool isLocked;
  final String? password;
  final List<SeatModel> seats;
  final List<ChatMessageModel> messages;
  final DateTime createdAt;
  final String ownerId;
  final int maxMembers;
  final bool micEnabled;
  final bool soundEnabled;

  ChatRoomModel({
    required this.id,
    required this.name,
    required this.theme,
    this.isLocked = false,
    this.password,
    required this.seats,
    required this.messages,
    required this.createdAt,
    required this.ownerId,
    this.maxMembers = 10,
    this.micEnabled = true,
    this.soundEnabled = true,
  });

  static List<SeatModel> createDefaultSeats() {
    return [
      // VIP (2)
      SeatModel(id: 'vip_1', type: SeatType.vip, position: 0),
      SeatModel(id: 'vip_2', type: SeatType.vip, position: 1),
      // Partner (4)
      SeatModel(id: 'partner_1', type: SeatType.partner, position: 2),
      SeatModel(id: 'partner_2', type: SeatType.partner, position: 3),
      SeatModel(id: 'partner_3', type: SeatType.partner, position: 4),
      SeatModel(id: 'partner_4', type: SeatType.partner, position: 5),
      // Normal (4)
      SeatModel(id: 'normal_1', type: SeatType.normal, position: 6),
      SeatModel(id: 'normal_2', type: SeatType.normal, position: 7),
      SeatModel(id: 'normal_3', type: SeatType.normal, position: 8),
      SeatModel(id: 'normal_4', type: SeatType.normal, position: 9),
    ];
  }
}

enum SeatType { vip, partner, normal }

class SeatModel {
  final String id;
  final SeatType type;
  final int position;
  bool isOccupied;
  String? userId;
  String? userName;
  String? userAvatar;
  bool isMicOn;
  bool isSpeaking;

  SeatModel({
    required this.id,
    required this.type,
    required this.position,
    this.isOccupied = false,
    this.userId,
    this.userName,
    this.userAvatar,
    this.isMicOn = true,
    this.isSpeaking = false,
  });
}

class ChatMessageModel {
  final String id;
  final String userId;
  final String userName;
  final String? userAvatar;
  final String content;
  final DateTime timestamp;
  final MessageType type;
  final String? giftId;
  final int? giftCount;

  ChatMessageModel({
    required this.id,
    required this.userId,
    required this.userName,
    this.userAvatar,
    required this.content,
    required this.timestamp,
    this.type = MessageType.text,
    this.giftId,
    this.giftCount,
  });
}

enum MessageType { text, gift, system, join, leave }

// ============================================================
// lib/core/models/user_model.dart
// ============================================================
class UserModel {
  final String id;
  final String nickname;
  final String? phone;
  final String? email;
  final String? avatarUrl;
  final Gender gender;
  final int charmPoints;
  final int totalCoins;
  final int level;
  final int experience;
  final String? familyId;
  final String? familyRole;
  final List<String> ownedFrames;
  final List<String> ownedRings;
  final String? currentFrame;
  final String? currentRing;
  final DateTime createdAt;
  final DateTime lastActive;
  final int dailyActivityMinutes;
  final bool isOnline;

  UserModel({
    required this.id,
    required this.nickname,
    this.phone,
    this.email,
    this.avatarUrl,
    required this.gender,
    this.charmPoints = 0,
    this.totalCoins = 0,
    this.level = 1,
    this.experience = 0,
    this.familyId,
    this.familyRole,
    this.ownedFrames = const [],
    this.ownedRings = const [],
    this.currentFrame,
    this.currentRing,
    required this.createdAt,
    required this.lastActive,
    this.dailyActivityMinutes = 0,
    this.isOnline = false,
  });
}

enum Gender { male, female, other }
