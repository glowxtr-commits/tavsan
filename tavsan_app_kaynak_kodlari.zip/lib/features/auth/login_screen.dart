
// ============================================================
// lib/features/splash/splash_screen.dart
// ============================================================
import 'package:flutter/material.dart';
import '../auth/login_screen.dart';
import '../../core/theme/app_theme.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 3), vsync: this,
    );
    _controller.forward().then((_) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 200, height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [AppTheme.primaryColor.withOpacity(0.3), Colors.transparent],
                ),
              ),
              child: const Center(child: Text('🐰', style: TextStyle(fontSize: 120))),
            ),
            const SizedBox(height: 30),
            AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                return Opacity(
                  opacity: _controller.value,
                  child: const Text(
                    'TAVŞAN',
                    style: TextStyle(
                      fontFamily: 'Poppins', fontSize: 48,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryColor, letterSpacing: 8,
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 10),
            const Text(
              'Sosyal Oyun Platformu',
              style: TextStyle(fontSize: 16, color: AppTheme.textSecondary),
            ),
            const SizedBox(height: 50),
            SizedBox(
              width: 150,
              child: LinearProgressIndicator(
                backgroundColor: AppTheme.cardColor,
                valueColor: const AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// lib/features/auth/login_screen.dart
// ============================================================
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/providers/auth_provider.dart';
import '../home/home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _phoneController = TextEditingController();
  final _emailController = TextEditingController();
  final _otpController = TextEditingController();
  bool _showOTP = false;
  bool _isPhoneSelected = true;

  @override
  void dispose() {
    _phoneController.dispose();
    _emailController.dispose();
    _otpController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);

    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 40),
              Container(
                width: 120, height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [AppTheme.primaryColor.withOpacity(0.3), Colors.transparent],
                  ),
                  border: Border.all(color: AppTheme.primaryColor.withOpacity(0.5), width: 2),
                ),
                child: const Center(child: Text('🐰', style: TextStyle(fontSize: 60))),
              ),
              const SizedBox(height: 20),
              const Text('TAVŞAN',
                style: TextStyle(
                  fontFamily: 'Poppins', fontSize: 36,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryColor, letterSpacing: 6,
                ),
              ),
              const SizedBox(height: 8),
              const Text('Şifre yok, sadece eğlence!',
                style: TextStyle(fontSize: 14, color: AppTheme.textSecondary),
              ),
              const SizedBox(height: 40),

              Container(
                decoration: BoxDecoration(
                  color: AppTheme.cardColor, borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: _AuthMethodButton(
                        icon: Icons.phone, label: 'Telefon',
                        isSelected: _isPhoneSelected,
                        onTap: () => setState(() { _isPhoneSelected = true; _showOTP = false; }),
                      ),
                    ),
                    Expanded(
                      child: _AuthMethodButton(
                        icon: Icons.email, label: 'E-posta',
                        isSelected: !_isPhoneSelected,
                        onTap: () => setState(() { _isPhoneSelected = false; _showOTP = false; }),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              if (_isPhoneSelected) _buildPhoneInput()
              else _buildEmailInput(),

              const SizedBox(height: 16),

              if (_showOTP) ...[
                _buildOTPInput(),
                const SizedBox(height: 16),
              ],

              SizedBox(
                width: double.infinity, height: 56,
                child: ElevatedButton(
                  onPressed: authProvider.isLoading ? null : () => _handleMainAction(authProvider),
                  child: authProvider.isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : Text(_showOTP ? 'Doğrula' : 'Kod Gönder',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                ),
              ),

              const SizedBox(height: 30),

              Row(
                children: [
                  Expanded(child: Divider(color: AppTheme.textMuted)),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    child: Text('veya', style: TextStyle(color: AppTheme.textMuted)),
                  ),
                  Expanded(child: Divider(color: AppTheme.textMuted)),
                ],
              ),

              const SizedBox(height: 24),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _SocialButton(icon: '🍎', label: 'Apple', onTap: () => authProvider.signInWithApple()),
                  const SizedBox(width: 16),
                  _SocialButton(icon: '📘', label: 'Facebook', onTap: () {}),
                  const SizedBox(width: 16),
                  _SocialButton(icon: '𝕏', label: 'Twitter', onTap: () {}),
                  const SizedBox(width: 16),
                  _SocialButton(icon: 'G', label: 'Google', onTap: () => authProvider.signInWithGoogle()),
                ],
              ),

              const SizedBox(height: 40),

              const Text(
                'Giriş yaparak Kullanım Koşulları ve Gizlilik Politikasını kabul etmiş olursunuz.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: AppTheme.textMuted),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPhoneInput() {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardColor, borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: const Row(
              children: [
                Text('🇹🇷', style: TextStyle(fontSize: 20)),
                SizedBox(width: 8),
                Text('+90', style: TextStyle(
                  color: AppTheme.textPrimary, fontSize: 16, fontWeight: FontWeight.w500,
                )),
              ],
            ),
          ),
          Container(width: 1, height: 24, color: AppTheme.textMuted),
          Expanded(
            child: TextField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              style: const TextStyle(color: AppTheme.textPrimary),
              decoration: const InputDecoration(
                hintText: 'Telefon numaranız',
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(horizontal: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmailInput() {
    return TextField(
      controller: _emailController,
      keyboardType: TextInputType.emailAddress,
      style: const TextStyle(color: AppTheme.textPrimary),
      decoration: const InputDecoration(
        hintText: 'E-posta adresiniz',
        prefixIcon: Icon(Icons.email, color: AppTheme.textSecondary),
      ),
    );
  }

  Widget _buildOTPInput() {
    return TextField(
      controller: _otpController,
      keyboardType: TextInputType.number,
      maxLength: 6,
      textAlign: TextAlign.center,
      style: const TextStyle(
        color: AppTheme.textPrimary, fontSize: 24,
        letterSpacing: 8, fontWeight: FontWeight.bold,
      ),
      decoration: const InputDecoration(
        hintText: '------',
        hintStyle: TextStyle(color: AppTheme.textMuted, fontSize: 24, letterSpacing: 8),
        counterText: '',
      ),
    );
  }

  void _handleMainAction(AuthProvider authProvider) async {
    if (_showOTP) {
      final success = await authProvider.verifyPhoneOTP(_otpController.text);
      if (success && mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const HomeScreen()),
        );
      }
    } else {
      if (_isPhoneSelected) {
        final phone = '+90${_phoneController.text}';
        await authProvider.sendPhoneOTP(phone);
        setState(() => _showOTP = true);
      } else {
        await authProvider.sendEmailLink(_emailController.text);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('E-posta doğrulama linki gönderildi!'),
            backgroundColor: AppTheme.successColor,
          ),
        );
      }
    }
  }
}

class _AuthMethodButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _AuthMethodButton({
    required this.icon, required this.label,
    required this.isSelected, required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.primaryColor : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: isSelected ? Colors.white : AppTheme.textSecondary, size: 18),
            const SizedBox(width: 8),
            Text(label, style: TextStyle(
              color: isSelected ? Colors.white : AppTheme.textSecondary,
              fontWeight: FontWeight.w600,
            )),
          ],
        ),
      ),
    );
  }
}

class _SocialButton extends StatelessWidget {
  final String icon;
  final String label;
  final VoidCallback onTap;

  const _SocialButton({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 70,
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: AppTheme.cardColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppTheme.textMuted.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Text(icon, style: const TextStyle(fontSize: 24)),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(fontSize: 10, color: AppTheme.textSecondary)),
          ],
        ),
      ),
    );
  }
}
