
// ============================================================
// lib/features/home/home_screen.dart
// ============================================================
import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../chat/chat_rooms_screen.dart';
import '../family/family_screen.dart';
import '../shop/shop_screen.dart';
import '../profile/profile_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    const ChatRoomsScreen(),
    const FamilyScreen(),
    const ShopScreen(),
    const ProfileScreen(),
  ];

  final List<String> _titles = ['Sohbet Odaları', 'Ailem', 'Mağaza', 'Profilim'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_currentIndex]),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: AppTheme.cardColor,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppTheme.goldColor.withOpacity(0.5)),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('🪙', style: TextStyle(fontSize: 16)),
                SizedBox(width: 6),
                Text('12,450',
                  style: TextStyle(
                    color: AppTheme.goldColor,
                    fontWeight: FontWeight.bold, fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      body: _screens[_currentIndex],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: AppTheme.surfaceColor,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 10, offset: const Offset(0, -5),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) => setState(() => _currentIndex = index),
          backgroundColor: Colors.transparent,
          elevation: 0,
          type: BottomNavigationBarType.fixed,
          selectedItemColor: AppTheme.primaryColor,
          unselectedItemColor: AppTheme.textSecondary,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.chat_bubble_outline),
              activeIcon: Icon(Icons.chat_bubble),
              label: 'Sohbet',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.people_outline),
              activeIcon: Icon(Icons.people),
              label: 'Aile',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.shopping_bag_outlined),
              activeIcon: Icon(Icons.shopping_bag),
              label: 'Mağaza',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_outline),
              activeIcon: Icon(Icons.person),
              label: 'Profil',
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// lib/features/chat/chat_rooms_screen.dart
// ============================================================
import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import 'chat_room_detail_screen.dart';

class ChatRoomsScreen extends StatelessWidget {
  const ChatRoomsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final rooms = [
      {'name': 'Tavşan Kulübü', 'theme': 'Neon', 'users': 8, 'max': 10, 'locked': false},
      {'name': 'Altın Odası', 'theme': 'Altın', 'users': 6, 'max': 10, 'locked': true},
      {'name': 'Eğlence Merkezi', 'theme': 'Parti', 'users': 10, 'max': 10, 'locked': false},
      {'name': 'Gece Sohbeti', 'theme': 'Karanlık', 'users': 4, 'max': 10, 'locked': false},
      {'name': 'Müzik Odası', 'theme': 'Müzik', 'users': 7, 'max': 10, 'locked': false},
    ];

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: rooms.length,
      itemBuilder: (context, index) {
        final room = rooms[index];
        return _RoomCard(
          name: room['name'] as String,
          theme: room['theme'] as String,
          users: room['users'] as int,
          maxUsers: room['max'] as int,
          isLocked: room['locked'] as bool,
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const ChatRoomDetailScreen()),
            );
          },
        );
      },
    );
  }
}

class _RoomCard extends StatelessWidget {
  final String name;
  final String theme;
  final int users;
  final int maxUsers;
  final bool isLocked;
  final VoidCallback onTap;

  const _RoomCard({
    required this.name, required this.theme,
    required this.users, required this.maxUsers,
    required this.isLocked, required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isFull = users >= maxUsers;

    return GestureDetector(
      onTap: isFull ? null : onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isFull
              ? AppTheme.errorColor.withOpacity(0.5)
              : AppTheme.primaryColor.withOpacity(0.3),
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 60, height: 60,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [AppTheme.primaryColor, AppTheme.secondaryColor],
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Center(child: Text('🐰', style: TextStyle(fontSize: 30))),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(name, style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w600, color: AppTheme.textPrimary,
                      )),
                      if (isLocked) ...[
                        const SizedBox(width: 8),
                        const Icon(Icons.lock, size: 16, color: AppTheme.warningColor),
                      ],
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(theme, style: const TextStyle(
                    fontSize: 12, color: AppTheme.textSecondary,
                  )),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  children: [
                    const Icon(Icons.people, size: 16, color: AppTheme.textSecondary),
                    const SizedBox(width: 4),
                    Text('$users/$maxUsers',
                      style: TextStyle(
                        fontSize: 14,
                        color: isFull ? AppTheme.errorColor : AppTheme.textSecondary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: isFull
                      ? AppTheme.errorColor.withOpacity(0.2)
                      : AppTheme.successColor.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    isFull ? 'DOLU' : 'KATIL',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      color: isFull ? AppTheme.errorColor : AppTheme.successColor,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
