
// ============================================================
// lib/features/chat/chat_room_detail_screen.dart
// 2-4-4 Koltuk Düzeni + Hediye + Mesajlaşma
// ============================================================
import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../core/models/chat_room_model.dart';
import '../../core/models/gift_model.dart';
import '../../core/providers/gift_provider.dart';
import 'package:provider/provider.dart';

class ChatRoomDetailScreen extends StatefulWidget {
  const ChatRoomDetailScreen({super.key});

  @override
  State<ChatRoomDetailScreen> createState() => _ChatRoomDetailScreenState();
}

class _ChatRoomDetailScreenState extends State<ChatRoomDetailScreen> {
  final TextEditingController _messageController = TextEditingController();
  bool _micOn = true;
  bool _soundOn = true;
  bool _showGiftPanel = false;

  // Demo seats
  final List<Map<String, dynamic>> _seats = [
    {'id': 'vip_1', 'type': 'vip', 'user': 'Ahmet', 'avatar': '👨', 'mic': true},
    {'id': 'vip_2', 'type': 'vip', 'user': null, 'avatar': null, 'mic': false},
    {'id': 'partner_1', 'type': 'partner', 'user': 'Ayşe', 'avatar': '👩', 'mic': true},
    {'id': 'partner_2', 'type': 'partner', 'user': 'Mehmet', 'avatar': '👨', 'mic': false},
    {'id': 'partner_3', 'type': 'partner', 'user': null, 'avatar': null, 'mic': false},
    {'id': 'partner_4', 'type': 'partner', 'user': 'Fatma', 'avatar': '👩', 'mic': true},
    {'id': 'normal_1', 'type': 'normal', 'user': 'Ali', 'avatar': '👦', 'mic': true},
    {'id': 'normal_2', 'type': 'normal', 'user': null, 'avatar': null, 'mic': false},
    {'id': 'normal_3', 'type': 'normal', 'user': 'Zeynep', 'avatar': '👧', 'mic': true},
    {'id': 'normal_4', 'type': 'normal', 'user': null, 'avatar': null, 'mic': false},
  ];

  final List<Map<String, dynamic>> _messages = [
    {'user': 'Ahmet', 'text': 'Merhaba herkese!', 'isMe': false},
    {'user': 'Ayşe', 'text': 'Selam 🐰', 'isMe': false},
    {'user': 'Ben', 'text': 'Nasılsınız?', 'isMe': true},
    {'user': 'Mehmet', 'text': 'İyiyiz teşekkürler', 'isMe': false},
  ];

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      appBar: AppBar(
        title: const Text('Tavşan Kulübü'),
        actions: [
          // Günlük Aktiflik Süresi
          Container(
            margin: const EdgeInsets.only(right: 8),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: AppTheme.cardColor,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.timer, size: 14, color: AppTheme.secondaryColor),
                SizedBox(width: 4),
                Text('2s 15dk', style: TextStyle(
                  fontSize: 12, color: AppTheme.secondaryColor, fontWeight: FontWeight.w600,
                )),
              ],
            ),
          ),
          // 4 Nokta Menü
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert),
            color: AppTheme.cardColor,
            onSelected: (value) {
              // Menü işlemleri
            },
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'settings', child: Text('Oda Ayarları')),
              const PopupMenuItem(value: 'users', child: Text('Kullanıcı Listesi')),
              const PopupMenuItem(value: 'rules', child: Text('Oda Kuralları')),
              const PopupMenuItem(value: 'report', child: Text('Şikayet Et')),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // Koltuk Düzeni (2-4-4)
          Container(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                // VIP Row (2)
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildSeat(_seats[0]),
                    const SizedBox(width: 20),
                    _buildSeat(_seats[1]),
                  ],
                ),
                const SizedBox(height: 12),
                // Partner Row (4)
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildSeat(_seats[2]),
                    const SizedBox(width: 12),
                    _buildSeat(_seats[3]),
                    const SizedBox(width: 12),
                    _buildSeat(_seats[4]),
                    const SizedBox(width: 12),
                    _buildSeat(_seats[5]),
                  ],
                ),
                const SizedBox(height: 12),
                // Normal Row (4)
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildSeat(_seats[6]),
                    const SizedBox(width: 12),
                    _buildSeat(_seats[7]),
                    const SizedBox(width: 12),
                    _buildSeat(_seats[8]),
                    const SizedBox(width: 12),
                    _buildSeat(_seats[9]),
                  ],
                ),
              ],
            ),
          ),

          // Mesajlar
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final msg = _messages[index];
                return _buildMessageBubble(msg);
              },
            ),
          ),

          // Hediye Paneli (açık/kapalı)
          if (_showGiftPanel) _buildGiftPanel(),

          // Alt Kontrol Barı
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.surfaceColor,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  blurRadius: 10,
                  offset: const Offset(0, -5),
                ),
              ],
            ),
            child: SafeArea(
              child: Row(
                children: [
                  // Ses Aç/Kapat
                  IconButton(
                    icon: Icon(_soundOn ? Icons.volume_up : Icons.volume_off,
                      color: _soundOn ? AppTheme.primaryColor : AppTheme.textMuted),
                    onPressed: () => setState(() => _soundOn = !_soundOn),
                  ),
                  // Mikrofon Aç/Kapat
                  IconButton(
                    icon: Icon(_micOn ? Icons.mic : Icons.mic_off,
                      color: _micOn ? AppTheme.successColor : AppTheme.errorColor),
                    onPressed: () => setState(() => _micOn = !_micOn),
                  ),
                  // Mesaj Yaz
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        color: AppTheme.cardColor,
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: TextField(
                        controller: _messageController,
                        style: const TextStyle(color: AppTheme.textPrimary),
                        decoration: const InputDecoration(
                          hintText: 'Bir şeyler yaz...',
                          hintStyle: TextStyle(color: AppTheme.textMuted),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(vertical: 10),
                        ),
                      ),
                    ),
                  ),
                  // Hediye Butonu
                  IconButton(
                    icon: const Icon(Icons.card_giftcard, color: AppTheme.goldColor),
                    onPressed: () => setState(() => _showGiftPanel = !_showGiftPanel),
                  ),
                  // Gönder
                  IconButton(
                    icon: const Icon(Icons.send, color: AppTheme.primaryColor),
                    onPressed: () {
                      if (_messageController.text.isNotEmpty) {
                        setState(() {
                          _messages.add({
                            'user': 'Ben',
                            'text': _messageController.text,
                            'isMe': true,
                          });
                          _messageController.clear();
                        });
                      }
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSeat(Map<String, dynamic> seat) {
    final isOccupied = seat['user'] != null;
    final type = seat['type'] as String;
    final isMicOn = seat['mic'] as bool;

    Color seatColor;
    switch (type) {
      case 'vip':
        seatColor = AppTheme.goldColor;
        break;
      case 'partner':
        seatColor = AppTheme.silverColor;
        break;
      default:
        seatColor = AppTheme.bronzeColor;
    }

    return GestureDetector(
      onTap: () {
        if (isOccupied) {
          // Kullanıcı profiline git
        }
      },
      child: Container(
        width: 60,
        height: 70,
        decoration: BoxDecoration(
          color: isOccupied ? AppTheme.cardColor : AppTheme.surfaceColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isOccupied ? seatColor : AppTheme.textMuted.withOpacity(0.3),
            width: 2,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: isOccupied
                      ? seatColor.withOpacity(0.2)
                      : AppTheme.textMuted.withOpacity(0.1),
                  ),
                  child: Center(
                    child: Text(
                      isOccupied ? seat['avatar'] : '+',
                      style: TextStyle(
                        fontSize: 20,
                        color: isOccupied ? seatColor : AppTheme.textMuted,
                      ),
                    ),
                  ),
                ),
                if (isOccupied && isMicOn)
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: Container(
                      width: 12,
                      height: 12,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppTheme.successColor,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              isOccupied ? seat['user'] : 'Boş',
              style: TextStyle(
                fontSize: 9,
                color: isOccupied ? AppTheme.textPrimary : AppTheme.textMuted,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMessageBubble(Map<String, dynamic> msg) {
    final isMe = msg['isMe'] as bool;
    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: isMe ? AppTheme.primaryColor.withOpacity(0.8) : AppTheme.cardColor,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (!isMe)
              Text(msg['user'], style: const TextStyle(
                fontSize: 11, color: AppTheme.secondaryColor, fontWeight: FontWeight.w600,
              )),
            Text(msg['text'], style: const TextStyle(
              fontSize: 14, color: AppTheme.textPrimary,
            )),
          ],
        ),
      ),
    );
  }

  Widget _buildGiftPanel() {
    final giftProvider = Provider.of<GiftProvider>(context);

    return Container(
      height: 280,
      decoration: BoxDecoration(
        color: AppTheme.surfaceColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: Column(
        children: [
          // Sekmeler
          DefaultTabController(
            length: 4,
            child: Column(
              children: [
                const TabBar(
                  tabs: [
                    Tab(text: 'Basit'),
                    Tab(text: 'Orta'),
                    Tab(text: 'Büyük'),
                    Tab(text: 'Mega'),
                  ],
                  labelColor: AppTheme.primaryColor,
                  unselectedLabelColor: AppTheme.textSecondary,
                  indicatorColor: AppTheme.primaryColor,
                ),
                SizedBox(
                  height: 200,
                  child: TabBarView(
                    children: [
                      _buildGiftGrid(giftProvider.basicGifts),
                      _buildGiftGrid(giftProvider.mediumGifts),
                      _buildGiftGrid(giftProvider.bigGifts),
                      _buildGiftGrid(giftProvider.megaGifts),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGiftGrid(List<GiftModel> gifts) {
    return GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        childAspectRatio: 0.8,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemCount: gifts.length,
      itemBuilder: (context, index) {
        final gift = gifts[index];
        return GestureDetector(
          onTap: () {
            // Hediye gönder
            final explosion = Provider.of<GiftProvider>(context, listen: false)
                .sendGift(gift);

            setState(() {
              _messages.add({
                'user': 'Ben',
                'text': '${gift.emoji} ${gift.name} hediye etti!',
                'isMe': true,
              });
              _showGiftPanel = false;
            });

            if (explosion.coinAmount > 0) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    '${CoinExplosionService.getExplosionText(explosion.type)} +${explosion.coinAmount} jeton!',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  backgroundColor: CoinExplosionService.getExplosionColor(explosion.type),
                ),
              );
            }
          },
          child: Container(
            decoration: BoxDecoration(
              color: AppTheme.cardColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: gift.price >= 100
                  ? AppTheme.goldColor.withOpacity(0.3)
                  : Colors.transparent,
              ),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(gift.emoji, style: const TextStyle(fontSize: 28)),
                const SizedBox(height: 4),
                Text(gift.name, style: const TextStyle(
                  fontSize: 10, color: AppTheme.textPrimary,
                ), textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 2),
                Text('${gift.price}', style: const TextStyle(
                  fontSize: 11, color: AppTheme.goldColor, fontWeight: FontWeight.bold,
                )),
              ],
            ),
          ),
        );
      },
    );
  }
}
