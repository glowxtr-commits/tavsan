
// ============================================================
// lib/features/family/family_screen.dart
// ============================================================
import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../core/models/family_model.dart';
import '../../core/providers/family_provider.dart';
import 'package:provider/provider.dart';

class FamilyScreen extends StatelessWidget {
  const FamilyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final familyProvider = Provider.of<FamilyProvider>(context);
    final family = familyProvider.currentFamily;

    if (family == null) {
      return _buildNoFamilyView(context);
    }

    return _buildFamilyView(context, family);
  }

  Widget _buildNoFamilyView(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('👨‍👩‍👧‍👦', style: TextStyle(fontSize: 80)),
          const SizedBox(height: 20),
          const Text(
            'Henüz Bir Ailen Yok',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: AppTheme.textPrimary,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Aile kurarak güçlen ve arkadaşlarınla birlikte oyna!',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppTheme.textSecondary),
          ),
          const SizedBox(height: 30),
          ElevatedButton.icon(
            onPressed: () => _showCreateFamilyDialog(context),
            icon: const Icon(Icons.add),
            label: const Text('Aile Kur (20K)'),
          ),
          const SizedBox(height: 16),
          TextButton(
            onPressed: () {},
            child: const Text('Bir Aileye Katıl'),
          ),
        ],
      ),
    );
  }

  Widget _buildFamilyView(BuildContext context, FamilyModel family) {
    final config = FamilyModel.getLevelConfig(family.level);
    final nextConfig = family.level < 12
        ? FamilyModel.getLevelConfig(family.level + 1)
        : null;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Aile Başlığı
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [AppTheme.primaryColor.withOpacity(0.3), AppTheme.accentColor.withOpacity(0.3)],
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppTheme.primaryColor.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Container(
                  width: 70, height: 70,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppTheme.primaryColor.withOpacity(0.2),
                    border: Border.all(color: AppTheme.goldColor, width: 2),
                  ),
                  child: const Center(child: Text('🏰', style: TextStyle(fontSize: 36))),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(family.name, style: const TextStyle(
                        fontSize: 22, fontWeight: FontWeight.bold, color: AppTheme.textPrimary,
                      )),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: AppTheme.goldColor.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text('Lv.${family.level}', style: const TextStyle(
                              color: AppTheme.goldColor, fontWeight: FontWeight.bold, fontSize: 12,
                            )),
                          ),
                          const SizedBox(width: 8),
                          Text('${family.memberCount}/${family.maxMembers} üye',
                            style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          // Fon Bilgisi
          _buildInfoCard(
            icon: '💰',
            title: 'Aile Fonu',
            value: '${family.fund.toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (match) => '.')}',
            subtitle: 'Günlük kesinti: ${family.dailyFundCost}',
          ),

          const SizedBox(height: 12),

          // Aktivite
          _buildInfoCard(
            icon: '⚡',
            title: 'Toplam Aktivite',
            value: '${family.totalActivity}',
            subtitle: 'Sandık açmak için aktivite kazan',
          ),

          const SizedBox(height: 20),

          // Rütbe Dağılımı
          const Text('Rütbe Dağılımı', style: TextStyle(
            fontSize: 16, fontWeight: FontWeight.w600, color: AppTheme.textPrimary,
          )),
          const SizedBox(height: 12),
          Row(
            children: [
              _buildRoleBadge('Lider', '👑', AppTheme.goldColor),
              const SizedBox(width: 8),
              _buildRoleBadge('Lider Yrd. x${config['leaderAsst']}', '🎖️', AppTheme.silverColor),
              const SizedBox(width: 8),
              _buildRoleBadge('Admin x${config['admin']}', '🛡️', AppTheme.bronzeColor),
              if ((config['manager'] as int) > 0) ...[
                const SizedBox(width: 8),
                _buildRoleBadge('Yönetici x${config['manager']}', '⭐', AppTheme.accentColor),
              ],
            ],
          ),

          const SizedBox(height: 20),

          // Yükseltme
          if (nextConfig != null) ...[
            const Text('Seviye Yükseltme', style: TextStyle(
              fontSize: 16, fontWeight: FontWeight.w600, color: AppTheme.textPrimary,
            )),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.cardColor,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Lv.${family.level} → Lv.${family.level + 1}', style: const TextStyle(
                        color: AppTheme.textPrimary, fontWeight: FontWeight.w600,
                      )),
                      Text('${nextConfig['fundReq']} fon gerekli', style: const TextStyle(
                        color: AppTheme.goldColor, fontWeight: FontWeight.bold,
                      )),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: family.fund / (nextConfig['fundReq'] as int),
                      backgroundColor: AppTheme.surfaceColor,
                      valueColor: const AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),
                      minHeight: 8,
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: familyProvider.canUpgradeLevel()
                          ? () => familyProvider.upgradeLevel()
                          : null,
                      child: const Text('Yükselt'),
                    ),
                  ),
                ],
              ),
            ),
          ],

          const SizedBox(height: 20),

          // Koruma Kalkanı
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: family.hasShield
                  ? AppTheme.successColor.withOpacity(0.1)
                  : AppTheme.errorColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: family.hasShield
                    ? AppTheme.successColor.withOpacity(0.3)
                    : AppTheme.errorColor.withOpacity(0.3),
              ),
            ),
            child: Row(
              children: [
                Text(family.hasShield ? '🛡️' : '⚠️', style: const TextStyle(fontSize: 32)),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        family.hasShield ? 'Koruma Kalkanı Aktif' : 'Koruma Kalkanı Yok',
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          color: family.hasShield ? AppTheme.successColor : AppTheme.errorColor,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        family.hasShield
                            ? 'Ailen hırsızlığa karşı korunuyor'
                            : '300K jetonla 7 günlük kalkan al',
                        style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary),
                      ),
                    ],
                  ),
                ),
                if (!family.hasShield)
                  ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.goldColor,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      textStyle: const TextStyle(fontSize: 12),
                    ),
                    child: const Text('300K Al'),
                  ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          // Günlük Kapsül
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.cardColor,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                const Text('🎁', style: TextStyle(fontSize: 40)),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Günlük Kapsül', style: TextStyle(
                        fontWeight: FontWeight.w600, color: AppTheme.textPrimary,
                      )),
                      const SizedBox(height: 4),
                      const Text('Her gün 1 ücretsiz kapsül aç!', style: TextStyle(
                        fontSize: 12, color: AppTheme.textSecondary,
                      )),
                    ],
                  ),
                ),
                ElevatedButton(
                  onPressed: () => _showCapsuleResult(context),
                  child: const Text('Aç'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard({
    required String icon,
    required String title,
    required String value,
    required String subtitle,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.cardColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Text(icon, style: const TextStyle(fontSize: 32)),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(
                  fontSize: 12, color: AppTheme.textSecondary,
                )),
                const SizedBox(height: 4),
                Text(value, style: const TextStyle(
                  fontSize: 20, fontWeight: FontWeight.bold, color: AppTheme.goldColor,
                )),
                const SizedBox(height: 4),
                Text(subtitle, style: const TextStyle(
                  fontSize: 11, color: AppTheme.textMuted,
                )),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRoleBadge(String label, String emoji, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 14)),
          const SizedBox(width: 4),
          Text(label, style: TextStyle(
            fontSize: 11, color: color, fontWeight: FontWeight.w600,
          )),
        ],
      ),
    );
  }

  void _showCreateFamilyDialog(BuildContext context) {
    final nameController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surfaceColor,
        title: const Text('Aile Kur', style: TextStyle(color: AppTheme.textPrimary)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              style: const TextStyle(color: AppTheme.textPrimary),
              decoration: const InputDecoration(
                hintText: 'Aile adı',
                hintStyle: TextStyle(color: AppTheme.textMuted),
              ),
            ),
            const SizedBox(height: 16),
            const Text('Maliyet: 20.000 jeton', style: TextStyle(
              color: AppTheme.goldColor, fontWeight: FontWeight.bold,
            )),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('İptal'),
          ),
          ElevatedButton(
            onPressed: () {
              Provider.of<FamilyProvider>(context, listen: false)
                  .createFamily(nameController.text, '🏰');
              Navigator.pop(context);
            },
            child: const Text('Kur'),
          ),
        ],
      ),
    );
  }

  void _showCapsuleResult(BuildContext context) {
    final result = TheftService.openDailyCapsule();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surfaceColor,
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('🎁', style: TextStyle(fontSize: 60)),
            const SizedBox(height: 16),
            Text(result.description, textAlign: TextAlign.center, style: const TextStyle(
              color: AppTheme.textPrimary, fontSize: 16,
            )),
            if (result.amount != null) ...[
              const SizedBox(height: 8),
              Text('+${result.amount}', style: const TextStyle(
                fontSize: 28, fontWeight: FontWeight.bold, color: AppTheme.goldColor,
              )),
            ],
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Harika!'),
          ),
        ],
      ),
    );
  }
}
